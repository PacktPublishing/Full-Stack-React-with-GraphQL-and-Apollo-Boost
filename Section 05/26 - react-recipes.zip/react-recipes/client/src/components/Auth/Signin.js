import React from "react";

class Signin extends React.Component {
  render() {
    return <div>Signin</div>;
  }
}

export default Signin;
